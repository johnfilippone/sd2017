/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1package;

/**
 *
 * @author don
 */
public class ReflectionTest {
    public double d0, d1[], d2[][], d3[][][];
    
    public static int i1;
    
    public static void main(String args[]) {}
    
    public static void main2(String[] args) {}
    
    public String[][] test(int[] a) {
        return null;
    }

    public String[] testr(char[] a, byte b[], short s[], float f[], boolean[] bl, double[][] d, String[][] x) {
        return null;
    }
    
    void ignore() { }
    
    int ingoreMe2;
    
    public ReflectionTest(int a, int b, int c) {
        
    }
    
}
