the directories to evaluate are:

graff

Notepad

quark

yparser
