package quark;

abstract class I extends tree { 
   // methods common to all I nodes
}
