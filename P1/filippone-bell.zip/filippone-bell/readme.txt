all prog1.pl files for the assigned packages are in the results directory
