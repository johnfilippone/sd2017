The most money ever paid for a cow in an auction was $1.3 million.
