package edu.uiuc.detectRefactorings.util;

public interface Constants {

	String initialVersion = "detectRefactorings.initialVersion";
	String subsequentVersion = "detectRefactorings.secondaryVersion";
	
	

}
