dbase(sol3,[node,arc]).
table(node,[nid,"name",ntokens,isPlace]).
table(arc,[aid,cap,startsAt,endsAt]).



