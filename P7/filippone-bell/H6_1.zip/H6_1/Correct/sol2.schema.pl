dbase(sol2,[place,tbox,arc]).
table(place,[pid,"name",ntokens]).
table(tbox,[tid,"name"]).
table(arc,[aid,cap,toTbox,pid,tid]).


