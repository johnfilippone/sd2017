dbase(sol1,[token,place,tbox,arc]).
table(token,[kid,inside]).
table(place,[pid,"name"]).
table(tbox,[tid,"name"]).
table(arc,[aid,cap,toTbox,pid,tid]).
