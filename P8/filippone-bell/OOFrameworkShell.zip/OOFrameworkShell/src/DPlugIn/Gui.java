package DPlugIn;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Don
 */
public class Gui extends Framework.Gui {

}
