/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package DPlugIn;

/**
 *
 * @author Don
 */
public class Calc extends Framework.Calc {

}
