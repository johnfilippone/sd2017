/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BIPlugIn;

import Framework.Calc;
import Framework.Gui;

public class Factory extends Framework.Factory {

    @Override
    public Calc NewCalc() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Gui NewGui() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
