package BIPlugIn;

public class Gui extends Framework.Gui {

}
