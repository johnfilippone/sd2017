/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BIPlugIn;


public class Calc extends Framework.Calc  {


}

