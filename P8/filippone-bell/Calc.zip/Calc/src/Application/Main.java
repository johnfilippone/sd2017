/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Application;

public class Main {
    public static void main(String args[]) {
        new D.Gui("DCalc").display();
        //new BI.Gui("BICalc").display();
    }
}
