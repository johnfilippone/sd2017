#!/bin/bash
CLASSPATH=$PWD:
CLASSPATH+=$PWD/OOFrameworkShell/src:
CLASSPATH+=$PWD/OOFrameworkShell/src/Application:
CLASSPATH+=$PWD/OOFrameworkShell/src/Framework:
CLASSPATH+=$PWD/OOFrameworkShell/src/BIPlugIn:
CLASSPATH+=$PWD/OOFrameworkShell/src/DPlugIn:
export CLASSPATH
echo "done"
