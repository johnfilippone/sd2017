package Framework;


public abstract class Calc {

  public abstract void sub(String n);
  public abstract void mul(String n);
  public abstract void add(String n);
  public abstract void div(String n);
  public abstract String get();
  public abstract void set(String n);
  public abstract void clear();
}
