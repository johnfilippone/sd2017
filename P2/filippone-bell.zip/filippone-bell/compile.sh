#!/bin/bash
echo "Compiling classes..."
javac src/VPL/Conform.java
javac tests/VPL/ConformTest.java
echo "Classes compiled!"
