/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package parallelsort;

/**
 *
 * @author Don
 */
public class ReportError {
    public static void msg( String s ) {
        System.out.println(s);
        System.exit(1);
    }
}
