package myPackage;

import p.actions.*;

public class MyClass {
	public void myMethod() {
		RPackage pkg = RProject.getPackage("RefactoringCrawlerWithVisitor",
				"edu.uiuc.detectRefactorings.detection");
		RClassOrInterface cls = pkg.getClass("Visitor");
		// String[] sig = {"visit", "edu.uiuc.detectRefactorings.util.Node",
		// "edu.uiuc.detectRefactorings.util.FieldDetection"};
		// RMethod seed = cls.getMethod(sig);

		// /////////////////////////////////////////////////////////////////////
		//
		// Write your script that undoes a Visitor
		//
		RMethod inlinedMethod = null;
		
		// Step 1: for each method in Visitor, do the followings
		for (RMethod method : cls.getAllMethods()) {
			// (1) move back to the original class
			RParameter parameter = method.getParameter(0);
			method.move(parameter);
			// (2) replace with an "accept" method
			inlinedMethod = method.replace("accept");

		}
		// Step 2: for each relative method (of "accept"), do the followings
		for (RMethod relative : inlinedMethod.getRelatives()) {
			// (1) remove a Visitor-type parameter
			relative.removeParameter(relative.getParameter(0));
			// (2) rename to the original name
			relative.rename("isRename");
		}
		inlinedMethod.removeParameter(inlinedMethod.getParameter(0));
		inlinedMethod.rename("isRename");
		
		// Step 3: delete Visitor class
		cls.delete();

		//
		// /////////////////////////////////////////////////////////////////////
	}
}