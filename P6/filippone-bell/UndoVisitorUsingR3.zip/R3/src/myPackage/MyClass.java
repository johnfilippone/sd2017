package myPackage;

import p.actions.*;

public class MyClass {
	public void myMethod() {
		RPackage pkg = RProject.getPackage("RefactoringCrawlerWithVisitor", "edu.uiuc.detectRefactorings.detection");
		RClassOrInterface cls = pkg.getClass("Visitor");
		//String[] sig = {"visit", "edu.uiuc.detectRefactorings.util.Node", "edu.uiuc.detectRefactorings.util.FieldDetection"};
		//RMethod seed = cls.getMethod(sig);
		

		///////////////////////////////////////////////////////////////////////
		//
		//	Write your script that undoes a Visitor 
		//

		// Step 1: for each method in Visitor, do the followings
		for ( RMethod method : cls.getAllMethods() ) {
			// (1) move back to the original class
			RParameter parameter = method.getParameter(2);
			RMethod movedMethod = method.move(parameter);
			// (2) replace with an "accept" method
		}
		// Step 2: for each relative method (of "accept"), do the followings
                //         (1) remove a Visitor-type parameter

                //         (2) rename to the original name


		// Step 3: delete Visitor class		
		
		//
		///////////////////////////////////////////////////////////////////////
	}
}