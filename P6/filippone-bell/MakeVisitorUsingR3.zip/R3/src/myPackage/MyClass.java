package myPackage;

import p.actions.*;

public class MyClass {
	public void myMethod() {
		RPackage pkg = RProject.getPackage("RefactoringCrawler", "edu.uiuc.detectRefactorings.detection");
		RClassOrInterface cls = pkg.getClass("FieldDetection");
		String[] sig = {"computeLikeliness", "edu.uiuc.detectRefactorings.util.Node", "edu.uiuc.detectRefactorings.util.Node"};
		RMethod seed = cls.getMethod(sig);

		///////////////////////////////////////////////////////////////////////
		//
		//	Write your script that makes a Visitor
		//

		// Step 1: create a new Visitor class
		RClassOrInterface visitor = pkg.newClass("Visitor");

		// Step 2: add a singleton field to the Visitor
		visitor.addSingleton();

		// Step 3: for each relative method (of the seed), do the followings
		
		RMethod aDelegate = null;
		RParameter parameter = null;
 
		for ( RMethod temp : seed.getRelatives() ) {
		// (1) add a Visitor-type parameter
			parameter = temp.addParameter(visitor, "null");
			
		// (2) if movable, move to Visitor and leave a delegate named "accept"
			if(temp.isMovable(parameter)) {
				aDelegate = temp.moveAndDelegate(parameter);
				temp.rename("visit");
			}
		}
		
		// (3) if not movable, rename to "accept"	
		for ( RMethod temp : aDelegate.getRelatives() ) {
			temp.rename("accept");
		}
		//
		///////////////////////////////////////////////////////////////////////
	}
}