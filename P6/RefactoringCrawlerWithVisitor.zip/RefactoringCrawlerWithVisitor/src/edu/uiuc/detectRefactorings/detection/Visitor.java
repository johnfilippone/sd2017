package edu.uiuc.detectRefactorings.detection;

public class Visitor {

	public static final Visitor instance = new Visitor();

	public boolean visit(edu.uiuc.detectRefactorings.detection.MoveClassDetection edu_uiuc_detectrefactorings_detection_moveclassdetection) {
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.ClassDetection edu_uiuc_detectrefactorings_detection_classdetection) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.PackageDetection edu_uiuc_detectrefactorings_detection_packagedetection) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.RenamePackageDetection edu_uiuc_detectrefactorings_detection_renamepackagedetection) {
		return true;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.FieldDetection edu_uiuc_detectrefactorings_detection_fielddetection) {
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.MethodDetection edu_uiuc_detectrefactorings_detection_methoddetection) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.PullUpMethodDetection edu_uiuc_detectrefactorings_detection_pullupmethoddetection) {
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.MoveMethodDetection edu_uiuc_detectrefactorings_detection_movemethoddetection) {
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.PushDownMethodDetection edu_uiuc_detectrefactorings_detection_pushdownmethoddetection) {
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.RenameMethodDetection edu_uiuc_detectrefactorings_detection_renamemethoddetection) {
		return true;
	}

	public boolean visit(edu.uiuc.detectRefactorings.detection.ChangeMethodSignatureDetection edu_uiuc_detectrefactorings_detection_changemethodsignaturedetection) {
		return false;
	}
	public boolean visit(edu.uiuc.detectRefactorings.detection.RenameClassDetection edu_uiuc_detectrefactorings_detection_renameclassdetection) {
		return true;
	}
}